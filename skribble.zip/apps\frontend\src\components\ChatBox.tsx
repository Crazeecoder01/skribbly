import React from 'react';
import { useRoom } from '@/context/RoomContext';

interface User {
  id: string;
  name: string;
}
export default function ChatBox() {
  const { chatMessages, users, socket, room, userId, guess, setGuess, wordLength } = useRoom();

  const sendGuess = () => {
    if (!guess.trim()) return;
    socket.emit('send-guess', { roomCode: room!.code, guess, userId });
    setGuess('');
  };

  return (
    <div className="w-full max-w-xl mt-6 flex flex-col gap-4">
      <div className="bg-gray-800 rounded-xl p-4 shadow-md h-60 overflow-y-auto">
        {chatMessages.map((msg: { type: string; userId: string; message: string }, idx: number) => (
          <p
            key={idx}
            className={`text-sm mb-2 ${
              msg.type === 'correct' ? 'text-green-400 font-bold' : 'text-white'
            }`}
          >
            <strong>{users.find((u: User) => u.id === msg.userId)?.name || 'Unknown'}:</strong>{' '}
            {msg.message}
          </p>
        ))}
      </div>

      {room && userId !== room.createdBy && (
        <div className="flex gap-3">
          <input
            type="text"
            value={guess}
            onChange={(e) => setGuess(e.target.value)}
            className="flex-grow p-3 rounded-lg border-2 border-gray-600 text-white bg-gray-700 placeholder-gray-400 shadow"
            placeholder={`💬 Chat or guess the word (${wordLength ?? '_'})`}
            onKeyDown={(e) => e.key === 'Enter' && sendGuess()}
          />
          <button
            onClick={sendGuess}
            className="px-5 py-3 bg-green-600 hover:bg-green-700 rounded-xl text-white font-bold transition-transform hover:scale-105 shadow"
          >
            🚀 Send
          </button>
        </div>
      )}
    </div>
  );
}
