import React from 'react';
import { useRoom } from '@/context/RoomContext';
interface User {
  id: string;
  name: string;
}
export default function ScoreBoard() {
  const { scoreBoard, users } = useRoom();

  return (
    <section className="mb-8 w-full max-w-md">
      <h2 className="text-xl text-white mb-2">🏆 Scoreboard</h2>
      <ul className="bg-gray-800 text-white rounded-xl p-4 shadow space-y-2">
        {Object.entries(scoreBoard).map(([id, score]) => {
          const user = users.find((u:User) => u.id === id);
          return (
            <li key={id} className="flex justify-between">
              <span>{user?.name || 'Unknown'}</span>
              <span className="font-bold text-yellow-400">{score}</span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
