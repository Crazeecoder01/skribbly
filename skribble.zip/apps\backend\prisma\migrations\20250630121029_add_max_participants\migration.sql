-- AlterTable
ALTER TABLE "Room" ADD COLUMN     "maxParticipants" INTEGER NOT NULL DEFAULT 8;
