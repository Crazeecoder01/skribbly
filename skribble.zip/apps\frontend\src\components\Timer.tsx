import React from 'react';
import { useRoom } from '@/context/RoomContext';

export default function Timer() {
  const { timeLeft } = useRoom();
  return (
    <div className="text-2xl font-semibold text-white mb-4">
      ⏱️ Time Left: <span className="text-yellow-400">{timeLeft}s</span>
    </div>
  );
}
