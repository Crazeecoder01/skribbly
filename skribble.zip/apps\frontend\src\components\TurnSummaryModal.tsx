import React from 'react';
import { useRoom } from '@/context/RoomContext';

interface User {
  id: string;
  name: string;
}
export default function TurnSummaryModal() {
  const { turnSummary, users } = useRoom();
  if (!turnSummary) return null;

  const { drawerId, word, correctGuessers } = turnSummary;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-xl shadow-lg text-center w-[90%] max-w-md animate-fade-in">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">🕹️ Turn Summary</h2>
        <p className="mb-2 text-lg">
          <strong>Drawer:</strong>{' '}
          <span className="text-blue-700">
            {users.find((u: User) => u.id === drawerId)?.name || 'Unknown'}
          </span>
        </p>
        <p className="mb-2 text-lg">
          <strong>Word:</strong> <span className="text-green-600">{word}</span>
        </p>
        <p className="mb-4 text-lg">
          <strong>Guessed By:</strong>{' '}
          {correctGuessers.length > 0 ? (
            <span className="text-purple-600 font-semibold">
              {correctGuessers
                .map((id: string) => users.find((u: User) => u.id === id)?.name || 'Unknown')
                .join(', ')}
            </span>
          ) : (
            <span className="text-red-500 font-semibold">No one guessed it</span>
          )}
        </p>
        <p className="text-sm text-gray-500 italic">Next round starting...</p>
      </div>
    </div>
  );
}
